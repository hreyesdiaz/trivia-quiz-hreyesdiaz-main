# Kenzie Academy JavaScript Assignment

Trivia Quiz - Capstone project for Kenzie Academy by SNHU
